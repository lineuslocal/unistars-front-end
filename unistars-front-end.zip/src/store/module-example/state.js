export default function () {
  return {
    title: 'Applicant Management',
    back: false,
    url: ''
  }
}
