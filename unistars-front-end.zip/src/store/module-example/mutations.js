export function changeTitle (state, newTitle) {
  state.title = newTitle
}
export function changeBack (state, showBack) {
  state.back= showBack
}
export function changeUrl (state, url) {
  state.url= url
}