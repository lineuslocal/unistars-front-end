the front-end part of unistars

short tech list: vue.js nuxt.js Quasar
